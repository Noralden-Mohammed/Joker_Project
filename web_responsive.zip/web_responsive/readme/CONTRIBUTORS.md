- Dave Lasley \<<dave@laslabs.com>\>

- Jairo Llopis \<<jairo.llopis@tecnativa.com>\>

- [Onestein](https://www.onestein.nl):
  - Dennis Sluijk \<<d.sluijk@onestein.nl>\>
  - Anjeel Haria

- Sergio Teruel \<<sergio.teruel@tecnativa.com>\>

- Alexandre Díaz \<<dev@redneboa.es>\>

- Mathias Markl \<<mathias.markl@mukit.at>\>

- Iván Todorovich \<<ivan.todorovich@gmail.com>\>

- Sergey Shebanin \<<sergey@shebanin.ru>\>

- David Vidal \<<david.vidal@tecnativa.com>\>

- Taras Shabaranskyi \<<shabaranskij@gmail.com>\>
