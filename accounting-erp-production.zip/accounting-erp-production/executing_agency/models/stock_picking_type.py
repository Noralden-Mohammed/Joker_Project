from odoo import api ,models ,fields ,_  

class StockPickingType(models.Model):
    _inherit = ['stock.picking.type']
    
    # This field connects the service administration module and the inheritance model of the stock.picking.type
    executing_agency_id = fields.Many2one(comodel_name='executing.agency', string='Executing Agency', required=True, tracking=True, default=lambda self: self.env.user.executing_agency_id)
