from odoo import api ,models ,fields ,_  

class ExecutingAgency(models.Model):
    
    _inherit = 'res.users'
    
    # This field connects the service administration module and the inheritance model of the user
    executing_agency_id = fields.Many2one('executing.agency', string='Executing Agency', required=True, tracking=True)
