from odoo import api ,models ,fields ,_  

class ExecutingAgency(models.Model):
    
    _inherit = 'stock.location'
    
    # This field connects the service administration module and the inheritance model of the stock.warehouse
    executing_agency_id = fields.Many2one('executing.agency', string='Executing Agency', required=True, tracking=True)
