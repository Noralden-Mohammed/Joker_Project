
from odoo import api ,models ,fields ,_  

# This module is the service administration that determines which division each user of the program belongs to

class ExecutingAgency(models.Model):
    
    _name = "executing.agency"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Executing Agency"
    _rec_name = 'name'
    
    name = fields.Char(string='Executing Agency', required=True, tracking=True)
    
    # This function ensures that the entered name is don't write twice
    _sql_constraints = [('unique_name',
                         'unique(name)',
                         'A record with the same name already exists.')]
    
    
    
    
  