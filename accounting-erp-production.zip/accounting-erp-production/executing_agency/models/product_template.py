from odoo import api ,models ,fields ,_  

class ProductTemplate(models.Model):

    _inherit = ['product.template']
    
    # inherit and add field in product.template model 
    executing_agency_id = fields.Many2one('executing.agency', string='Executing Agency', required=True, tracking=True)
