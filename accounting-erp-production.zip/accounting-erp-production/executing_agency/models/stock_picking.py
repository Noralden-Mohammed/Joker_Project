from odoo import api ,models ,fields ,_  

class StockPicking(models.Model):
    _inherit = ['stock.picking']
    
    # inherit and add (executing_agency_id)field in product.template model 
    executing_agency_id = fields.Many2one('executing.agency', string='Executing Agency', readonly="1", 
    default=lambda self: self.env.user.executing_agency_id)
