# -*- coding: utf-8 -*-
{
    'name': "UMS",

    'summary': """unvierstey management system""",

    'description': """
        Student result
    """,
    
    'version': '16.0.1',
    'application': True,

    # any module necessary for this one to work correctly
    'depends': ['base','mail','project'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/sequnece_data.xml',

        'student/views/student_view.xml',
        'faculty/views/faculty_view.xml',

        'exam/views/exam_view.xml',
        'exam/views/exam_evaluation_view.xml',

        'result/views/result_view.xml',
        'result/views/result_history.xml',
        'result/views/supplement.xml',
        'result/views/portable.xml',
        # 'result/views/mark_sheet.xml',

        'settings/views/settings_view.xml',
        
        'settings/views/college_view.xml',
        'settings/views/department_view.xml',
        'settings/views/level_view.xml',
        'settings/views/academic_year_view.xml',
        'settings/views/ums_subject_view.xml',
        'settings/views/ums_division.xml',
        'settings/views/ums_semester.xml',
        'settings/views/ums_group.xml',
        'settings/views/ums_specialist.xml',
        'settings/views/ums_program_view.xml',
        # 'settings/views/ums_nationality.xml',
        'settings/views/class_view.xml',

        'result/reports/print_certificate.xml',
        'wizard/portable_wizard.xml',
        'wizard/ceritifcat_wizard_view.xml',
        

        
        # 'result/reports/certificate_template/medicine/bachelor_detials_english.xml',
        'result/reports/certificate_template/medicine/bachelor_detials_arabic.xml',
        'result/reports/certificate_template/bachelor_arabic.xml',
        'result/reports/certificate_template/bachelor_detials_arabic.xml',
        'settings/views/menu.xml',
    ],
}
