from odoo import fields, api, models, _
from odoo.exceptions import UserError
import datetime
from dateutil import relativedelta


class CeritifcatWizard(models.TransientModel):
    _name = 'ceritifcat.wizard'

    student = fields.Many2one('ums.student')
    result = fields.Many2one('ums.result')
    program = fields.Selection([("master", "Master"), ("bsc", "Bsc"), ("deploma", "Deploma")], default="bsc",
                               required=True, string="program")
    language = fields.Selection([("arabic", "Arabic"), ("english", "English")], default="arabic", string="language",
                                required=True)
    details = fields.Boolean(string="Details")
    
    semester_result = fields.Boolean(string="Semester Result")
    semester_type = fields.Many2one('ums.semester', 'Select Semester')
    result_id =fields.Many2one('ums.result', 'Select Result')

    @api.onchange('result_id')
    def onchange_specialist_id(self):
        for rec in self:
            return{'domain':{'semester_type':[('result_id.','=',rec.result_id.class_id.semester_id.id)]}}

    def validate(self):
        data = {
            'ids': self.ids,
            'model': self._name,
            'form': {
                'student': self.student.id,
                'details': self.details
            },
        }
        if self.program == "master" and self.language == "arabic":
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)
        elif self.program == "master" and self.language == "english":
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)

        # bsc program
        elif self.program == "bsc" and self.language == "arabic" and self.details:
            return self.env.ref('ums.action_bachelor_arabic_medicine').report_action(self, data=data)
        elif self.program == "bsc" and self.language == "arabic" and not self.details:
            return self.env.ref('ums.action_bachelor_arabic_medicine').report_action(self, data=data)

        elif self.program == "bsc" and self.language == "english" and self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)
        elif self.program == "bsc" and self.language == "english" and not self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)

        # deploma program
        elif self.program == "deploma" and self.language == "arabic" and self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)
        elif self.program == "deploma" and self.language == "arabic" and not self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)

        elif self.program == "deploma" and self.language == "english" and self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)
        elif self.program == "deploma" and self.language == "english" and not self.details:
            return self.env.ref('ums.action_bachelor_arabic').report_action(self, data=data)