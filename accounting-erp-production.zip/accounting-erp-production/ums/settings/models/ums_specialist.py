# -*- coding: utf-8 -*-
from datetime import date
from odoo import api, models, fields


class Specialist(models.Model):
    _name = "ums.specialist"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "University Specialist"

    name = fields.Char(string="Name", required=True)
    english_name = fields.Char(string="English Name", required=True)
    code = fields.Char(string="Code", required=True)
    department_id = fields.Many2one('ums.department', 'Department', required=True)
    college_id = fields.Many2one(related='department_id.college_id', string="College", required=True)
