from odoo import models, fields, api, _
from datetime import datetime
from dateutil import relativedelta


# need work
class Semester(models.Model):
    _name = "ums.semester"
    _description = "Semester"

    name = fields.Char('Name', required=True, help='Semester of the standard')
    english_name = fields.Char('English Name', required=True, help='Semester of the standard')
    code = fields.Char('Code', required=True,
                       help='Semester code')
    description = fields.Text('Description', help='Description')
    sequence = fields.Integer(string='Sequence')
    # specialize_id = fields.Many2one('college.specialize', string="Specialize Name")
    # subject_id = fields.One2many('subject.subject.line', 'semester_id',string="Subject")
