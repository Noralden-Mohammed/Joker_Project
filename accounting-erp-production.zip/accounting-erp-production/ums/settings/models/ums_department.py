from odoo import models, fields, api, _
from datetime import datetime
from dateutil import relativedelta


class Department(models.Model):
    _name = 'ums.department'
    _description = 'College Department'

    name = fields.Char('Name', required=True, help='Subject name')
    english_name = fields.Char('English Name', required=False, help='Subject name')

    college_id = fields.Many2one('ums.college', required=True,string="College Name")
