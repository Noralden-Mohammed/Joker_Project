from odoo import models, fields, api, _
from datetime import datetime
from dateutil import relativedelta

class Level(models.Model):
    _name = "ums.level"
    _description = "Level"

    name = fields.Char('Name', required=True, help='Name of level')
    english_name = fields.Char('English Name', required=False, help='Name of level')
    sequence = fields.Integer(string='Sequence')
