# -*- coding: utf-8 -*-

# from . import settings
from . import res_setting
from . import ums_college
from . import ums_department
from . import ums_level
from . import ums_academic_year
from . import ums_subject
from . import ums_division
from . import ums_semester
from . import ums_group
from . import ums_specialist
from . import ums_class
from . import ums_program
from . import nationality

