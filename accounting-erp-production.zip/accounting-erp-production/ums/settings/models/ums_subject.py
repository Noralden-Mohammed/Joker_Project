from odoo import models, fields, api, _
from datetime import datetime
from dateutil import relativedelta

class Subject(models.Model):

    _name = "ums.subject"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Subjects"

    name = fields.Char('Name', required=True, help='Subject name')
    english_name = fields.Char('English Name', required=False, help='Subject name')
    weight = fields.Float(string="Weight", tracking=True, required=False)
    hours = fields.Float(string="Hours", tracking=True, required=False)
    lab = fields.Boolean(string="Lab", tracking=True)