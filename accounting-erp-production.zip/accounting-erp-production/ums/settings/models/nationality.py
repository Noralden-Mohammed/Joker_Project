from odoo import models, fields, api, _
from datetime import datetime
from datetime import date
from dateutil import relativedelta


class Student(models.Model):
    _name = 'ums.nationality'
    _description = "Student Nationality"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    
    name = fields.Char(string='Name', tracking=True)    
    english_name = fields.Char(string='English Name', tracking=True)    
    