# -*- coding: utf-8 -*-
from datetime import date
from odoo import api, models, fields


class Group(models.Model):
    _name = "ums.group"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = "name"
    _description = "Groups"

    name = fields.Char(string="Name", required=True)
    english_name = fields.Char(string="English Name", required=True)
