from odoo import models, fields, api, _
from datetime import datetime
from dateutil import relativedelta


class Program(models.Model):
    _name = "ums.program"
    _description = "College Programs"

    name = fields.Char('Name', required=True, help='Name')
    english_name = fields.Char('English Name', required=False, help='Name')
    code = fields.Char('Code', help='Code')
    college = fields.Many2one("ums.college", string="College")
    department = fields.Many2one("ums.department", string="Department")
    program_type = fields.Selection([('deploma', 'Deploma'), ('bsc', 'Bsc'), ('master', 'Master')],
                                    string="Program type")
    level_line = fields.One2many("ums.program.level.line", "program_id", string="Level of program", 
    ondelete="cascade"
    )
    
    @api.onchange('college')
    def onchange_college(self):
        for rec in self:
            return {'domain': {'department': [('college_id', '=', rec.college.id)]}}
        
    


class ProgramLevel(models.Model):
    _name = "ums.program.level.line"
    _description = "Level of program"

    program_id = fields.Many2one("ums.program", string="program #")

    level = fields.Many2one("ums.level", string="Level")

    semester_line = fields.One2many("program.level.semester.line", "level_id",string="Semesters in levels with subject",
                                    ondelete="cascade")


class SemesterLine(models.Model):
    _name = "program.level.semester.line"
    _description = "Semester in program level with subjects in semester"

    level_id = fields.Many2one("ums.program.level.line", string="program level #")

    semester_id = fields.Many2one("ums.semester", string="Semester")

    subject_line = fields.One2many("program.semester.subject.line", "semester_id", string="Subjects of semester",
                                   ondelete="cascade")


class SubjectLine(models.Model):
    _name = "program.semester.subject.line"
    _description = "Subjects in semester of level in program record"

    semester_id = fields.Many2one("program.level.semester.line", string="semester #")

    subject = fields.Many2one("ums.subject", string="Subject")
