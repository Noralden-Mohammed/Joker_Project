# -*- coding: utf-8 -*-

from odoo import api, models, fields


class UniversityClass(models.Model):
    _name = "ums.class"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "University Class"

    name = fields.Char(string="Class Name", required=True)
    english_name = fields.Char(string="Class English Name", required=False)
    code = fields.Char(string="Code")

    program_id = fields.Many2one('ums.program', string="Program")
    college_id = fields.Many2one('ums.college', string="College")
    department_id = fields.Many2one('ums.department', string="Department")
    level = fields.Many2one('ums.level', string="Level")
    academic_year = fields.Many2one('ums.academic.year', string="Academic Year")
    semester_id = fields.Many2one('ums.semester', string="Semester")

    specialist_id = fields.Many2one('ums.specialist', string="Specialist")

    class_strength = fields.Integer(string="Class Strength")

    group_id = fields.Many2one('ums.group', string="Group")
    std_line_ids = fields.One2many('ums.student', 'class_id', "Student Line", ondelete="cascade")

    student_count = fields.Integer(string="Student Count", compute='_compute_student_count', tracking=True)
    faculity_id = fields.Many2one('ums.faculty', 'Faculity')
        
    @api.onchange('college_id')
    def onchange_college_id(self):
        for rec in self:
            return {'domain': {'department_id': [('college_id', '=', rec.college_id.id)]}}
        
    @api.onchange('department_id')
    def onchange_department_id(self):
        for rec in self:
            return {'domain': {'specialist_id': [('department_id', '=', rec.department_id.id)]}}

    def _compute_student_count(self):
        for rec in self:
            studeent_count = self.env['ums.student'].search_count([('class_id', '=', rec.id)])
            # payment_count = self.env['account.payment'].search_count([('partner_id', '=', rec.partner_id.id)])
            rec.student_count = studeent_count

    # This Function of Smart Button Student Count
    def action_student(self):
        for rec in self:
            domain = [('class_id', '=', rec.id)]
            return {
                'type': 'ir.actions.act_window',
                'name': 'Student',
                'res_model': 'ums.student',
                'domain': domain,
                'view_mode': 'tree,form',
                'target': 'current',

            }

# class StudentLine(models.Model):
#     _inherit = "ums.student"

#     class_id = fields.Many2one('ums.class', string="Class")
#
