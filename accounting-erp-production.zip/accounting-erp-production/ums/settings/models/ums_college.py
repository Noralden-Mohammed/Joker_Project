from odoo import models, fields


class College(models.Model):
    _name = 'ums.college'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'University College'

    name = fields.Char('Name', required=True, help='College name')
    english_name = fields.Char(string='English Name', required=False, help='College name')

    department_ids = fields.One2many('ums.department', 'college_id', string='Departments')
    dean_name = fields.Char(string="Dean Name", tracking=True)
    dean_english_name = fields.Char(string="Dean English Name", tracking=True)
    registrar_name = fields.Char(string="Registrar Name", tracking=True)
    registrar_english_name = fields.Char(string="Registrar English Name", tracking=True)
    report_certificate_id = fields.Many2one('ir.actions.report', 'Certificate Template', tracking=True)
