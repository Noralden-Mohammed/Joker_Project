from odoo import models, fields, api, _
from datetime import datetime
from datetime import date
from dateutil import relativedelta


class Student(models.Model):
    _name = 'ums.student'
    _description = "Students records"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']

    name = fields.Char("Student Name", required=False, tracking=True)
    english_name = fields.Char("Student Name", required=False, tracking=True)
    student_number = fields.Char("Student Number", required=False, tracking=True)

    age = fields.Integer(string="Age", compute="_compute_age")
    booking_date = fields.Date(string="Booking Date", default=fields.Date.context_today)
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Gender", required=False, tracking=True)
    date_of_birth = fields.Date(string="Date_Of_Birth", required=False, tracking=True)
    blood_group = fields.Selection([('a+', 'A+'),
                                    ('a-', 'A-'),
                                    ('b+', 'B+'),
                                    ('o+', 'O+'),
                                    ('o-', 'O-'),
                                    ('ab-', 'AB-'),
                                    ('ab+', 'AB+')],
                                   string='Blood Group', required=False, tracking=True)
    nationality_id = fields.Many2one('ums.nationality', string='Nationality', ondelete='restrict', tracking=True)
    mother_name = fields.Char(string="Mother Name", tracking=True)
    # std_name = fields.Char(string='Full Name')
    first_name = fields.Char(string='First Name', required=False, tracking=True)
    first_english_name = fields.Char(string='First English Name', required=False, tracking=True)
    middle_name = fields.Char(string='Middle Name', required=False, tracking=True)
    middle_english_name = fields.Char(string='Middle English Name', required=False, tracking=True)
    sur_name = fields.Char(string='Surname', required=False, tracking=True)
    sur_english_name = fields.Char(string='English Surname', required=False, tracking=True)
    last_name = fields.Char(string='Last Name', required=False, tracking=True)
    last_english_name = fields.Char(string='Last English Name', required=False, tracking=True)
    image = fields.Binary(string='Image',
                          attachment=True, )
    ref = fields.Char(string='Reference', tracking=True)
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.user.company_id)

    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone", required=False)
    mobile = fields.Char(string="Mobile")

    college_id = fields.Many2one("ums.college", string="College")
    department = fields.Many2one("ums.department", string="Department")
    level = fields.Many2one("ums.level", string="Level")
    academic_year = fields.Many2one(related='class_id.academic_year', string="Academic Year")
    # program = fields.Selection([("master", "Master"), ("bsc", "Bsc"), ("deploma", "Deploma")], default="bsc",
    #                            required=False, string="program", invisible=True)

    program = fields.Many2one('ums.program', 'Program')

    final_result = fields.Float(string="Final Result")
    final_result_letter = fields.Float(string="Final Result Letter")
    grade_date = fields.Date(string="Grade Date")

    admission_date = fields.Datetime(string="Admission Date", default=fields.Datetime.now, required=False)
    specialist_id = fields.Many2one('ums.specialist', string="Specialist", required=False)

    semester_id = fields.Many2one('ums.semester', string="Semester", required=False)
    # semestar_id = fields.Many2one(related='class_id.semestar_id', string="Semestar", tracking=True, readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('approve', 'Approve'),
        ('done', 'Done'), ], string="Status", default='draft', required=False)

    class_id = fields.Many2one('ums.class', string="Class")
    result_count = fields.Integer(string="Result Count", compute='_compute_result_count', tracking=True)

    # class_history_ids = fields.One2many('class.history.line', 'student_id', 'Class History')
    # class_id = fields.Many2one('university.class', 'Class')
    # group = fields.Many2one(related='class_id.group_id', string="Group")

    def _compute_result_count(self):
        for rec in self:
            result_count = self.env['ums.result.history'].search_count([('name', '=', rec.id)])
            rec.result_count = result_count

    # This Function of Smart Button Result Count
    def action_result(self):
        for rec in self:
            domain = [('name', '=', rec.id)]
            return {
                'type': 'ir.actions.act_window',
                'name': 'Result History',
                'res_model': 'ums.result.history',
                'domain': domain,
                'view_mode': 'tree,form',
                'target': 'current',

            }

    def action_confirm(self):
        for rec in self:
            rec.state = 'approve'

    def action_approve(self):
        for rec in self:
            rec.state = 'done'

    #     student_lines = self.env['student.line']

    #     # Find matching records in university.class model
    #     class_records = self.env['university.class'].search([('name','=',self.class_id.name),
    #         ('college_id', '=', self.college_id.name),
    #         ('specialist_id', '=', self.specialist_id.name),
    #         ('acadimic_id','=',self.acadimic_id.name),
    #         ('semestar_id','=',self.semestar_id.name),
    #     ])
    #     if self.semestar_id != self.class_id.semestar_id:
    #             raise ValidationError(_("The Semestar is not Equal Class Semestar"))
    #     else :
    #         for class_record in class_records:
    #             vals = {
    #                 'name': self.std_name,
    #                 'gender': self.gender,
    #                 'class_id': class_record.id,
    #                 'age': self.age,
    #                 'blood_group': self.blood_group,
    #                 'semestar_id': self.semestar_id.id
    #             }

    #             student_line = student_lines.create(vals)
    #             self.state = 'done'

    # return True

    def action_back(self):
        for rec in self:
            rec.state = 'draft'

    @api.onchange('college_id')
    def onchange_college_id(self):
        for rec in self:
            return {'domain': {'department': [('college_id', '=', rec.college_id.id)]}}

    @api.onchange('department')
    def onchange_department(self):
        for rec in self:
            return {'domain': {'specialist_id': [('department_id', '=', rec.department.id)]}}

    @api.onchange('college_id')
    def onchange_college_id_program(self):
        for rec in self:
            return {'domain': {'program': [('college', '=', rec.college_id.id)]}}

    @api.onchange('program')
    def onchange_college_id_class_id(self):
        for rec in self:
            return {'domain': {'class_id': [('program_id', '=', rec.program.id)]}}

    @api.onchange('first_name', 'middle_name', 'sur_name', 'last_name')
    def _onchange_fullname(self):
        self.name = "{} {} {} {}".format(
            self.first_name or '',
            self.middle_name or '',
            self.sur_name or '',
            self.last_name or ''
        ).strip()

    @api.onchange('first_english_name', 'middle_english_name', 'sur_english_name', 'last_english_name')
    def _onchange_name(self):
        self.english_name = "{} {} {} {}".format(
            self.first_english_name or '',
            self.middle_english_name or '',
            self.sur_english_name or '',
            self.last_english_name or ''
        ).strip()

    @api.depends("date_of_birth")
    def _compute_age(self):
        for rec in self:
            today = date.today()
            if rec.date_of_birth:
                rec.age = today.year - rec.date_of_birth.year
            else:
                rec.age = 1

    @api.model
    def create(self, vals):
        vals['ref'] = self.env['ir.sequence'].next_by_code('ums.student')
        return super(Student, self).create(vals)

    def write(self, vals):
        if not self.ref:
            vals['ref'] = self.env['ir.sequence'].next_by_code('ums.student')
        return super(Student, self).write(vals)

# class UmsClassHistory(models.Model):
#     _name = "class.history.line"

#     student_id = fields.Many2one('university.student', string="Student")
#     class_id = fields.Many2one('university.class', "Class")
#     acadmic_id = fields.Many2one('acadimic.year', "Academic Year")
