# -*- coding: utf-8 -*-
from datetime import date
from odoo import api, models, fields, _
from odoo.exceptions import UserError, ValidationError
import datetime


class ExamType(models.Model):
    _name = "ums.exam.type"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "University Exam Type"
    _rec_name = 'name'

    name = fields.Char(string="Name", required=False, tracking=True)
    exam_type = fields.Selection(string='Exam Type', selection=[
        ('mid_term', 'Mid Term'),
        ('final', ' Final Exam (Exam that promotes students to the next Semester)')
    ])


class Exam(models.Model):
    _name = "ums.exam"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "University Exam"

    name = fields.Char(string="Name", readonly=True, tracking=True, default='New')
    type_name = fields.Char(string='Name', required=True, tracking=True)
    type = fields.Many2one('ums.exam.type', 'Type', required=False, tracking=True, invisible=True)
    start_date = fields.Date(string="Start Data", required=True, tracking=True)
    end_date = fields.Date(string="End Data", required=True, tracking=True)
    class_id = fields.Many2one('ums.class', 'Class', required=True, tracking=True)
    program_id = fields.Many2one(related="class_id.program_id", string='Program')
    level_id = fields.Many2one("ums.level", string='Level', store=True)
    department_id = fields.Many2one(related="class_id.department_id", string='Department')
    academic_year = fields.Many2one(related="class_id.academic_year", string='Academic Year', required=True,
                                    tracking=True, )
    college_id = fields.Many2one('ums.college', string="College", required=True, tracking=True)
    specialist_id = fields.Many2one('ums.specialist', string="Specialist", required=True, tracking=True)
    # evaluation_ids = fields.One2many('ums.exam.evaluation', 'exam_evaluation_id')
    state = fields.Selection(
        [('draft', 'Draft'),
         ('ongoing', 'On Going'),
         ('close', 'Closed'),
         ('cancel', 'Canceled')],
        default='draft', string="State")
    subject_ids = fields.One2many('ums.exam.subject.line', 'exam_id', string="Subject Line")
    semester_id = fields.Many2one('ums.semester', string="Semestar", store=True)
    exam_type = fields.Selection(string='Exam Type', selection=[
        ('final', ' Final Exam (Exam that promotes students to the next Semester)'),
        ('supplement_exam', 'Supplement Exam'),
        ('alternatives_exam', 'Alternatives Exam'),
    ], required=True)

    @api.onchange('class_id')
    def onchange_level_id(self):
         for rec in self:
            if rec.exam_type == 'final':
                rec.level_id = rec.class_id.level
            elif rec.exam_type == 'supplement_exam':
                rec.level_id = rec.class_id.level

    @api.constrains('start_date', 'end_date')
    def check_dates(self):
        for rec in self:
            if rec.start_date > rec.end_date:
                raise ValidationError(_("Start date must be Anterior to end date"))

    @api.onchange('college_id')
    def onchange_college_id(self):
        for rec in self:
            return {'domain': {'specialist_id': [('college_id', '=', rec.college_id.id)]}}

    @api.onchange('specialist_id')
    def onchange_specialist_id(self):
        for rec in self:
            return {'domain': {'class_id': [('specialist_id', '=', rec.specialist_id.id)]}}

    def close_exam(self):
        for rec in self:
            comp = self.env['ums.exam.evaluation'].search([
                ('exam_id', '=', rec.name),
                ('college_id', '=', rec.college_id.name),
                ('specialist_id', '=', rec.specialist_id.name),
                ('class_id', '=', rec.class_id.name),
            ])
            for con in comp:
                if con.state != 'completed':
                    raise ValidationError(_("you can not close before completed valuation"))
            rec.state = 'close'

    def cancel_exam(self):
        self.state = 'cancel'

    def confirm_exam(self):
        if len(self.subject_ids) < 1:
            raise UserError(_('Please Add Subjects'))
        for rec in self:
            for t in rec.subject_ids:
                if not t.date:
                    raise UserError(_('Please Add Date'))
                elif not t.time_from:
                    raise UserError(_('Please Add Time From'))
                elif not t.time_to:
                    raise UserError(_('Please Add Time to'))
                else:
                    pass
        name = str(self.type_name) + '-' + str(self.start_date)[0:10]
        self.name = name
        self.state = 'ongoing'

    @api.onchange('level_id')
    def change_subject_line(self):
        for rec in self:
            if rec.exam_type == 'final':
                rec.subject_ids = False
                rec.semester_id = rec.class_id.semester_id
                for line in rec.program_id.level_line:
                    if rec.level_id and rec.level_id.id == line.level.id:
                        for t in line.semester_line:
                            if rec.semester_id and rec.semester_id.id == t.semester_id.id:
                                subject_vals = []
                                for l in t.subject_line:
                                    subject_vals.append((0, 0, {
                                        'subject_id': l.subject.id,
                                        # 'date':datetime.date.today(),
                                    }))
                                rec.subject_ids = subject_vals

            if rec.exam_type == 'supplement_exam':
                for line in rec.program_id.level_line:
                    if rec.level_id and rec.level_id.id == line.level.id:
                        semester_ids = [s.semester_id.id for s in line.semester_line]
                        return {'domain': {'semester_id': [('id', 'in', semester_ids)]}}


    @api.onchange('semester_id')
    def change_semester_id(self):
        for rec in self:
            if rec.exam_type == 'supplement_exam':
                supplement = self.env['ums.supplement'].search([
                    ('class_id', '=', rec.class_id.id),
                    ('program_id', '=', rec.program_id.id),
                    ('level_id', '=', rec.level_id.id),
                ])
                if supplement:
                    rec.subject_ids = False
                    for sec in supplement:
                        
                        if sec.firest_semstar.id == rec.semester_id.id:
                            subject_vals = []
                            existing_subjects = rec.subject_ids.mapped('subject_id')
                            for l in sec.supplement_ids:
                                if l.subject_id not in existing_subjects:
                                    subject_vals.append((0, 0, {
                                        'subject_id': l.subject_id.id,
                                    }))
                                   
                            if subject_vals:
                                rec.subject_ids = subject_vals
                        else:
                            if sec.second_semstar.id == rec.semester_id.id:
                                subject_vals = []
                                existing_subjects = rec.subject_ids.mapped('subject_id')
                                for res in sec.supplement_second_ids:
                                    if res.subject_id not in existing_subjects:
                                        subject_vals.append((0, 0, {
                                            'subject_id': res.subject_id.id,
                                        }))
                                if subject_vals:
                                    rec.subject_ids = subject_vals
        # for rec in self:
        #     if rec.exam_type == 'supplement_exam':
        #         supplement = self.env['ums.supplement'].search([
        #             ('class_id','=',rec.class_id.id),
        #             ('program_id','=',rec.program_id.id),
        #             ('level_id','=',rec.level_id.id),
        #         ])
        #         if supplement:
        #             for sec in supplement:
        #                 if sec.firest_semstar.id == rec.semester_id.id:
        #                     subject_vals = []
        #                     for l in sec.supplement_ids:
        #                         sub =  self.env['ums.exam.subject.line'].search([('subject_id','=',l.subject_id.id),('exam_id','=',rec.id)],limit=1)
        #                         print (sub)
        #                         subject_vals = []
        #                         if not sub :
        #                             subject_vals= {
        #                                     'subject_id':l.subject_id.id,
        #                                     'exam_id':rec.id,
        #                                 }
        #                             s_id = self.env['ums.exam.subject.line'].create(subject_vals)
        #                     # rec.subject_ids = subject_vals
        #                 else:
        #                     sec.second_semstar.id == rec.semester_id.id
        #                     subject_vals = []
        #                     for res in sec.supplement_second_ids:
        #                         subject_vals.append((0,0,{
        #                                 'subject_id':res.subject_id.id,
        #                             }))
        #                         rec.subject_ids = subject_vals


# class InheritExam(models.Model):
#     _inherit = 'ums.exam.evaluation'
    
#     exam_evaluation_id = fields.Many2one('ums.exam')
    
class SubjectLine(models.Model):
    _name = 'ums.exam.subject.line'
    _description = 'Subject Line'

    subject_id = fields.Many2one('ums.subject', string='Subject', required=True, tracking=True)
    date = fields.Date(string='Date', required=False, tracking=True)
    time_from = fields.Float(string='Time From', required=False, tracking=True)
    time_to = fields.Float(string='Time To', required=False, tracking=True)
    mark = fields.Integer(string='Mark', tracking=True)
    exam_id = fields.Many2one('ums.exam', string='Exam', required=False)
