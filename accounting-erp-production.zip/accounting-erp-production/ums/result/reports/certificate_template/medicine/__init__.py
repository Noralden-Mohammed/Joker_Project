from . import bachelor_detials_arabic
from . import bachelor_detials_english