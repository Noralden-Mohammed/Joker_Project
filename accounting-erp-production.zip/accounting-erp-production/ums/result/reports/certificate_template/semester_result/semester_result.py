# from odoo import api, fields, models
# import random


# class SemesterResultReport(models.TransientModel):
#     _name = 'semester.result'
#     _description = "Print Semenster Result Report"
