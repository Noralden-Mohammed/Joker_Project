from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

from datetime import datetime, date

from decimal import Decimal
from decimal import Decimal, ROUND_HALF_UP

class BachelorArabicDetails(models.AbstractModel):
    _name = 'report.ums.print_bachelor_details_arabic'

    @api.model
    def _get_report_values(self, docids, data=None):
        student = data['form']['student']
        details = data['form']['details']
        docs = []

        query = _("""select distinct r.result_date , r.id , r.name from ums_student_result as one
                    join ums_student_result_semester2 as two ON two.student = %s and one.student = %s 
                    join ums_result as r on one.result_id = r.id and r.program = 'bsc'
                    order by r.result_date """)%(str(student),str(student))
        self.env.cr.execute(query)
        vals = self.env.cr.fetchall()
        if vals:
            result_ids = self.env["ums.result"]
            for va in vals:
                result_obj = self.env["ums.result"].search([("id","=",va[1])])
                result_ids += result_obj
        
            student_obj = self.env['ums.student'].search([("id","=",student)])
            docs.append({
                'result_ids': result_ids,
                'student': student_obj,
            })
            print (docs)
            return {
                'docs_data': docs,
            }