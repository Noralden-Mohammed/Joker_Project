# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError, Warning
from datetime import datetime
from dateutil import relativedelta


class Result(models.Model):
    _name = 'ums.result'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Results management"

    name = fields.Char(string="Result Name", required=True)

    college = fields.Many2one("ums.college", string="College")
    department = fields.Many2one("ums.department", string="Department")
    level = fields.Many2one("ums.level", string="Level")
    academic_year = fields.Many2one("ums.academic.year", string="Academic Year")
    specialist_id = fields.Many2one('ums.specialist', string="Specialist", required=True, tracking=True)
    # program = fields.Selection([("master","Master"),("bsc","Bsc"),("deploma","Deploma")],default="bsc",required=True,string="program")
    program = fields.Many2one('ums.program', 'program')
    first_semester_result = fields.One2many("ums.result.first", "result_id", string="First semester")
    second_semester_result = fields.One2many("ums.result.second", "result_id", string="Second semester")
    class_id = fields.Many2one('ums.class', string='Class')
    result_date = fields.Date(string="Date", required=False)
    note_ids = fields.One2many('ums.result.note', 'note_id')
    state = fields.Selection([("draft", "Draft"), ("confirm", "Confirmed")], default="draft", string="status")
    firest_semstar = fields.Many2one('ums.semester', 'First Semstar')
    second_semstar = fields.Many2one('ums.semester', 'Second Semstar')
    supplement_count = fields.Integer(string="Supplement Count", compute='_compute_supplement_count', tracking=True)
    portable_count = fields.Integer(string="portable Count", compute='_compute_portable_count', tracking=True)
    exam_type = fields.Selection(string='Result Type', selection=[
        ('final', ' Final Result (Result that promotes students to the next Semester)'),
        ('supplement_exam', 'Supplement Result'),
    ], required=True)


    # def action_done(self):
    #     total_hours = 0
    #     total_degree = 0
    #     for subject in self.first_semester_result.subject_line:
    #         total_hours += subject.hours
    #         total_degree += subject.degree

    #     if total_hours > 0:
    #         calculated_degree = (total_hours / 10) * (total_degree / total_hours)
    #         self.semester_degree = str(calculated_degree)


    def _compute_supplement_count(self):
        for rec in self:
            supplement_count = self.env['ums.supplement'].search_count([('result_id', '=', rec.id)])
            rec.supplement_count = supplement_count

    def _compute_portable_count(self):
        for rec in self:
            portable_count = self.env['ums.portable'].search_count([('result_id', '=', rec.id)])
            rec.portable_count = portable_count

    # This Function of Smart Button Supplement Count
    def action_supplement(self):
        for rec in self:
            domain = [('result_id', '=', rec.id)]
            return {
                'type': 'ir.actions.act_window',
                'name': 'Supplements',
                'res_model': 'ums.supplement',
                'domain': domain,
                'view_mode': 'tree,form',
                'target': 'current',
            }

    # This Function of Smart Button Portable Count
    def action_portable(self):
        for rec in self:
            domain = [('result_id', '=', rec.id)]
            return {
                'type': 'ir.actions.act_window',
                'name': 'Portables',
                'res_model': 'ums.portable',
                'domain': domain,
                'view_mode': 'tree,form',
                'target': 'current',
            }

    def set_to_confirm(self):
        for rec in self:
            # program = self.env['ums.program'].search([('name', '=', rec.program.id)], limit=1)
            # if not program:
            #     program_vals = {
            #         'name': rec.program,
            #         'college': rec.college.id,
            #         'department': rec.department.id,
            #     }
            #     program = self.env['ums.program'].create(program_vals)
            result = self.env["ums.result"].search([('name', '=', rec.name)], limit=1)
            if not result:
                vals_4 = {
                    'name': rec.name,
                }
                result = self.env['ums.result'].create(vals_4)

            for line in rec.first_semester_result:
                for t in line.subject_line:
                    history = self.env['ums.result.history'].search([
                        ('result_id', '=', result.id),
                        ('name', '=', line.student.id),
                        ('class_id', '=', rec.class_id.id),
                    ], limit=1)
                    if not history:
                        history_vals = {
                            'result_id': result.id,
                            'name': line.student.id,
                            'collage_id': rec.college.id,
                            'department_id': rec.department.id,
                            'program_id': rec.program.id,
                            'class_id': rec.class_id.id,
                            'specialist_id': rec.specialist_id.id,
                            'level_id': rec.level.id,
                            'academic_year_id': rec.academic_year.id,
                            'date': rec.result_date,
                            'firest_semstar': rec.firest_semstar.id,
                            'second_semstar': rec.second_semstar.id,
                            # 'result_id': result.id,
                        }
                        history = self.env['ums.result.history'].create(history_vals)
                    history_line_first = self.env['first.result.history.line'].search([
                        ('subject_id', '=', t.subject.id),
                        ('history_id', '=', history.id),
                    ], limit=1)
                    degree_letter = self.env['ums.division'].search([
                        ('name', '=', t.degree_letter),
                    ], limit=1)
                    if not degree_letter:
                        degree_vals = {
                            'name': t.degree_letter
                        }
                        degree_letter.create(degree_vals)
                    if not history_line_first:
                        history_line_first_vals = {
                            'subject_id': t.subject.id,
                            'history_id': history.id,
                            'degree': t.degree,
                            'note': t.note,
                            'hours': t.hours,
                            'degree_letter': degree_letter.id,
                        }
                        history_line_first = self.env['first.result.history.line'].create(history_line_first_vals)
                    if t.pass_or_fail == False:
                        if rec.exam_type == 'final':
                            supplement = self.env['ums.supplement'].search([
                                ('exam_name', '=', result.name),
                                ('name', '=', line.student.id),
                                ('class_id', '=', rec.class_id.id),
                            ], limit=1)
                            if not supplement:
                                supplement_vals = {
                                    'exam_name': result.name,
                                    'name': line.student.id,
                                    'class_id': rec.class_id.id,
                                    'department': rec.department.id,
                                    'program_id': rec.program.id,
                                    'level_id': rec.level.id,
                                    'academic_year': rec.academic_year.id,
                                    'college_id': rec.college.id,
                                    'specialist_id': rec.specialist_id.id,
                                    'date': rec.result_date,
                                    'firest_semstar': rec.firest_semstar.id,
                                    'second_semstar': rec.second_semstar.id,
                                    'result_id': result.id,
                                }
                                supplement = self.env['ums.supplement'].create(supplement_vals)
                            supplement_line_first = self.env['first.supplement.line'].search([
                                ('subject_id', '=', t.subject.id),
                                ('supplement_id', '=', supplement.id),
                            ], limit=1)
                            degree_letter = self.env['ums.division'].search([
                                ('name', '=', t.degree_letter),
                            ], limit=1)
                            if not degree_letter:
                                degree_vals = {
                                    'name': t.degree_letter
                                }
                                degree_letter.create(degree_vals)

                            print("supplemnt")
                            if not supplement_line_first:
                                print("in if subject")
                                supplement_line_first_vals = {
                                    'subject_id': t.subject.id,
                                    'pass_or_fail': t.pass_or_fail,
                                    'mark_scored': t.degree,
                                    'degree_letter': degree_letter.id,
                                    'supplement_id': supplement.id,
                                    'sub_first_id': t.id,
                                }
                                supplement_line_first.create(supplement_line_first_vals)
                        elif rec.exam_type == 'supplement_exam':
                            portable = self.env['ums.portable'].search([
                                ('exam_name', '=', result.name),
                                ('name', '=', line.student.id),
                                ('class_id', '=', rec.class_id.id),
                            ], limit=1)
                            if not portable:
                                portable_vals = {
                                    'exam_name': result.name,
                                    'name': line.student.id,
                                    'class_id': rec.class_id.id,
                                    'department': rec.department.id,
                                    'program_id': rec.program.id,
                                    'level_id': rec.level.id,
                                    'academic_year': rec.academic_year.id,
                                    'college_id': rec.college.id,
                                    'specialist_id': rec.specialist_id.id,
                                    'date': rec.result_date,
                                    'firest_semstar': rec.firest_semstar.id,
                                    'second_semstar': rec.second_semstar.id,
                                    'result_id': result.id,
                                }
                                portable = self.env['ums.portable'].create(portable_vals)
                            portable_line_first = self.env['first.portable.line'].search([
                                ('subject_id', '=', t.subject.id),
                                ('portable_id', '=', portable.id),
                            ], limit=1)
                            degree_letter = self.env['ums.division'].search([
                                ('name', '=', t.degree_letter),
                            ], limit=1)
                            if not degree_letter:
                                degree_vals = {
                                    'name': t.degree_letter
                                }
                                degree_letter.create(degree_vals)
                            if not portable_line_first:
                                print("in if subject")
                                portable_line_first_vals = {
                                    'subject_id': t.subject.id,
                                    'pass_or_fail': t.pass_or_fail,
                                    'mark_scored': t.degree,
                                    'degree_letter': degree_letter.id,
                                    'portable_id': portable.id,
                                    'sub_first_id': t.id,
                                    'sub_first_regional_id': t.sub_id.id,
                                }
                                portable_line_first.create(portable_line_first_vals)
            for sec in rec.second_semester_result:
                for l in sec.subject_line:
                    history_second = self.env['ums.result.history'].search([
                        ('result_id', '=', result.id),
                        ('name', '=', sec.student.id),
                        ('class_id', '=', rec.class_id.id),
                    ], limit=1)
                    if not history_second:
                        history_vals_second = {
                            'result_id': result.id,
                            'name': sec.student.id,
                            'collage_id': rec.college.id,
                            'department_id': rec.department.id,
                            'program_id': rec.program.id,
                            'specialist_id': rec.specialist_id.id,
                            'level_id': rec.level.id,
                            'academic_year_id': rec.academic_year.id,
                            'date': rec.result_date,
                            'firest_semstar': rec.firest_semstar.id,
                            'second_semstar': rec.second_semstar.id,
                        }
                        history_second = self.env['ums.result.history'].create(history_vals_second)
                    history_line_second = self.env['second.result.history.line'].search([
                        ('subject_id', '=', l.subject.id),
                        ('history_id', '=', history_second.id),
                    ], limit=1)
                    degree_letter = self.env['ums.division'].search([
                        ('name', '=', l.degree_letter),
                    ], limit=1)
                    if not degree_letter:
                        degree_vals = {
                            'name': t.degree_letter
                        }
                        degree_letter.create(degree_vals)
                    if not history_line_second:
                        history_line_second_vals = {
                            'subject_id': l.subject.id,
                            'history_id': history_second.id,
                            'degree': l.degree,
                            'note': l.note,
                            'hours': l.hours,
                            'degree_letter': degree_letter.id,
                        }
                        history_line_second = self.env['second.result.history.line'].create(history_line_second_vals)
                    if l.pass_or_fail == False:
                        if rec.exam_type == 'final':
                            supplement = self.env['ums.supplement'].search([
                                ('exam_name', '=', result.name),
                                ('name', '=', sec.student.id),
                                ('class_id', '=', rec.class_id.id),
                            ], limit=1)
                            if not supplement:
                                supplement_vals = {
                                    'exam_name': result.name,
                                    'name': sec.student.id,
                                    'class_id': rec.class_id.id,
                                    'department': rec.department.id,
                                    'program_id': rec.program.id,
                                    'level_id': rec.level.id,
                                    'academic_year': rec.academic_year.id,
                                    'college_id': rec.college.id,
                                    'specialist_id': rec.specialist_id.id,
                                    'date': rec.result_date,
                                    'firest_semstar': rec.firest_semstar.id,
                                    'second_semstar': rec.second_semstar.id,
                                }
                                supplement.create(supplement_vals)
                            supplement_line_second = self.env['second.supplement.line'].search([
                                ('subject_id', '=', l.subject.id),
                                ('supplement_id', '=', supplement.id),
                            ], limit=1)
                            degree_letter = self.env['ums.division'].search([
                                ('name', '=', t.degree_letter),
                            ], limit=1)
                            if not supplement_line_second:
                                supplement_line_second_vals = {
                                    'subject_id': l.subject.id,
                                    'pass_or_fail': l.pass_or_fail,
                                    'mark_scored': l.degree,
                                    'degree_letter': degree_letter.id,
                                    'supplement_id': supplement.id,
                                    'sub_second_id': l.id,
                                }
                                supplement_line_second.create(supplement_line_second_vals)
                        elif rec.exam_type == 'supplement_exam':
                            portable = self.env['ums.portable'].search([
                                ('exam_name', '=', result.name),
                                ('name', '=', line.student.id),
                                ('class_id', '=', rec.class_id.id),
                            ], limit=1)
                            if not portable:
                                portable_vals = {
                                    'exam_name': result.name,
                                    'name': line.student.id,
                                    'class_id': rec.class_id.id,
                                    'department': rec.department.id,
                                    'program_id': rec.program.id,
                                    'level_id': rec.level.id,
                                    'academic_year': rec.academic_year.id,
                                    'college_id': rec.college.id,
                                    'specialist_id': rec.specialist_id.id,
                                    'date': rec.result_date,
                                    'firest_semstar': rec.firest_semstar.id,
                                    'second_semstar': rec.second_semstar.id,
                                    'result_id': result.id,
                                }
                                portable = self.env['ums.portable'].create(portable_vals)
                            portable_line_second = self.env['second.portable.line'].search([
                                ('subject_id', '=', t.subject.id),
                                ('portable_id', '=', portable.id),
                            ], limit=1)
                            degree_letter = self.env['ums.division'].search([
                                ('name', '=', t.degree_letter),
                            ], limit=1)
                            if not degree_letter:
                                degree_vals = {
                                    'name': t.degree_letter
                                }
                                degree_letter.create(degree_vals)
                            if not portable_line_second:
                                print("in if subject")
                                portable_line_second_vals = {
                                    'subject_id': t.subject.id,
                                    'pass_or_fail': t.pass_or_fail,
                                    'mark_scored': t.degree,
                                    'degree_letter': degree_letter.id,
                                    'portable_id': portable.id,
                                    'sub_first_id': t.id,
                                    'sub_second_regional_id': t.sub_id.id,
                                }
                                portable_line_second.create(portable_line_second_vals)
            rec.state = "confirm"

    def set_to_draft(self):
        self.state = "draft"


class ResultNote(models.Model):
    _name = 'ums.result.note'
    _description = 'Result Note'

    note_id = fields.Many2one('ums.result', 'Result#')
    note = fields.Char('Note')
    note_details = fields.Char('Note Details')
    note_second_id = fields.Many2one('ums.result.second')
    note_first_id = fields.Many2one('ums.result.first')


class FirstSemesterResult(models.Model):
    _name = 'ums.result.first'
    _description = "Result of first semester in each year"

    result_id = fields.Many2one("ums.result", string="Result #")
    student = fields.Many2one("ums.student", string="Student")
    semster_degree = fields.Char("Semester degree", store=True)
    note = fields.Text("Note")
    subject_line = fields.One2many("result.subject.line", "first_result_id", string="Subject result")
    note_ids = fields.One2many('ums.result.note', 'note_first_id')
    student_status = fields.Many2one('ums.student.status', 'Student Status', readonly=True)
    class_id = fields.Many2one('ums.class', 'Class', tracking=True, readonly=True)
    semestar_pass_or_fail = fields.Boolean(string="Pass?")
    
    @api.onchange('subject_line')
    def _onchange_subject_line(self):
        for rec in self:
            rec.compute_semester_degree()
            
    def compute_semester_degree(self):
        print("fdfd")
        for rec in self:
            total_hours = 0
            total_degree = 0
            for subject in rec.subject_line:
                total_hours += subject.hours
                total_degree += (subject.hours / 10) * subject.degree

            if total_hours > 0:
                calculated_degree =  (total_degree / total_hours)
                rec.semster_degree = str(calculated_degree)

class SecondSemesterResult(models.Model):
    _name = 'ums.result.second'
    _description = "Result of second semester in each year"

    result_id = fields.Many2one("ums.result", string="Result #")
    student = fields.Many2one("ums.student", string="Student")
    semster_degree = fields.Char("Semester degree")
    note = fields.Text("Note")
    note_ids = fields.One2many('ums.result.note', 'note_second_id')
    subject_line = fields.One2many("result.subject.line", "second_result_id", string="Subject result")
    student_status = fields.Many2one('ums.student.status', 'Student Status', readonly=True)
    class_id = fields.Many2one('ums.class', 'Class', tracking=True, readonly=True)
    semestar_pass_or_fail = fields.Boolean(string="Pass?")
    
    
    @api.onchange('subject_line')
    def _onchange_subject_line(self):
        for rec in self:
            rec.compute_semester_degree()
            
    def compute_semester_degree(self):
        print("fdfd")
        for rec in self:
            total_hours = 0
            total_degree = 0
            for subject in rec.subject_line:
                total_hours += subject.hours
                total_degree += (subject.hours / 10) * subject.degree

            if total_hours > 0:
                calculated_degree =  (total_degree / total_hours)
                rec.semster_degree = str(calculated_degree)
            
            

class SubjectResult(models.Model):
    _name = "result.subject.line"
    _description = "subject result"

    first_result_id = fields.Many2one("ums.result.first", string="First semester result")
    second_result_id = fields.Many2one("ums.result.second", string="Second semester result")

    subject = fields.Many2one("ums.subject", string="Subject")
    degree = fields.Float("Degree")
    hours = fields.Float(string='Hours')
    degree_letter = fields.Char("Degree in letter")
    pass_or_fail = fields.Boolean(string='Pass?', readonly=False)
    note = fields.Char("Note")
    sub_id = fields.Many2one('result.subject.line', string="ID")

    @api.onchange('subject')
    def subject_onchange(self):
        for rec in self:
            if rec.subject:
                rec.hours = rec.subject.hours
