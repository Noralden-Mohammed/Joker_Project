# -*- coding: utf-8 -*-
from . import wizard
from . import settings
from . import student
from . import faculty
from . import exam
from . import result
