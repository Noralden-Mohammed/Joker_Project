
# -*- coding: utf-8 -*-


# Copyright 2016 Eficent Business and IT Consulting Services S.L.
# (http://www.eficent.com)
# Copyright 2016 Serpent Consulting Services Pvt. Ltd.
# Copyright 2017 Tecnativa.
# Copyright 2018 iterativo.
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

{
    "name": "Account Custody custom",
    "version": "16.0.1.0.0",
    "sequence": 0,
    "license": "AGPL-3",
    "author": "RSF Team,"
    "RSF Telcom and comunication .,",
    "category": "Generic Modules/Accounting",
    "website": "https://github.com/gahiz/gahiz-erp.git",

    "depends": ["mail","account","base"],
    "data": [
        "security/ir.model.access.csv",
        "views/account_journal.xml",
        "data/sequence.xml",
        "views/res_partner.xml",
        "views/account_custody.xml",

    ],
    'installable': True,
    'application': True,
    'auto_install': False,

}