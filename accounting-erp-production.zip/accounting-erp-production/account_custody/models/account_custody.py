# -*- coding: utf-8 -*-
from datetime import date
from odoo import api, models, fields
from odoo.exceptions import ValidationError



class AccountCustody(models.Model):
    _name = 'account.custody' # model name 
    _inherit = ['mail.thread', 'mail.activity.mixin'] 
    _description = "Account Custody"
    _rec_name = "name"
    
    name = fields.Char(string="Name", tracking=True ,readonly=True)
    partner_id = fields.Many2one(comodel_name='res.partner', tracking=True, string="Partner", readonly=True)
    bill_id = fields.Many2one(comodel_name='account.move', string='Bill', tracking=True, readonly=True)
    amount = fields.Float(string='Amount', tracking=True)
    amount_to_remove = fields.Float(string='Amount To remove', tracking=True, readonly=True)
    payment_date = fields.Date(string='Pyamnet Date', tracking=True, readonly=True)
    remove_date = fields.Date(string='Remove Date', tracking=True , defualt=fields.Date.context_today)
    payment_journal_id = fields.Many2one(comodel_name='account.journal', string='Payment Journal', tracking=True, readonly=True)
    memo = fields.Char(string='Memo', tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('paid', 'Paid'),
        ('removed', 'Removed')], string="State", default='draft',  tracking=True)
    expense_type = fields.Selection(related='payment_journal_id.expense_type') # field related with Expense Type to use in remove custody  
    note = fields.Char(string='Note')
    account_cust_ids = fields.One2many('account.account.line', 'account_custody_id', string='Journal Items', )
    
    
    
    # Status Bar remove Funcotions
    def action_remove_custody(self):
        for rec in self:
            if rec.expense_type == 'custody':
                #if rec.amount == rec.amount_to_remove:
                rec.state = 'removed'
                rec.remove_date = fields.Date.today()
                #elif rec.amount != rec.amount_to_remove:
                #    raise ValidationError("Sorry The amout and amount to remove must be equal top remove the custody")
            # else:
            #     raise ValidationError("Sorry The expense type must be custody")
            # create journal entry to remove custody .... 
                vals=[]
                journal_invoice = self.env['account.move'].create({
                
                'state': 'draft',
                'ref':rec.bill_id.name,
                'note': rec.note,
                'name':rec.name,
                
                }) 
                
                for line in self.account_cust_ids:
                    vals={
                    'move_id': journal_invoice.id,
                    'account_id': line.name.id,  
                    'debit':line.debit_custody,
                    'credit':line.credit_custody,
                    'name':line.note,
                    'partner_id':rec.partner_id.id,
                    }
                    self.env['account.move.line'].create(vals)
                    
                
                return   journal_invoice    
            else:
                raise ValidationError("Sorry The expense type must be custody")


    # Status Bar draft Function
    # def action_draft(self):
    #     for rec in self:
    #         rec.state = 'draft'

    
    @api.model  # Auto Sequence Function
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('account.custody')
        return super(AccountCustody, self).create(vals)
    
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   