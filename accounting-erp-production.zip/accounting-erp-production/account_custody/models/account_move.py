from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError


class AccountMove(models.Model):
    _inherit = 'account.move'
    
    custody_id = fields.Many2one(string='Custody', comodel_name='account.custody')
    
    
    #Data entry validation
    # inherit of the function from account.move to account_custody   

    def action_post(self):
        # inherit of the function from account.move to account_custody
        vals = []
        res = super().action_post()
        custody_count = self.env['account.custody'].search_count([('bill_id','=',self.name)])
        if custody_count == 0:
            for rec  in self:
                if rec.amount_total <= 0:
                    raise ValidationError("The Amount Total cannot be Zeroo in the bill")
                elif rec.journal_id.expense_type =='custody':
                    vals={
                        'state':'draft',
                        'partner_id':self.partner_id.id,
                        'bill_id':self.id,
                        'amount':self.amount_total,
                        'payment_date':self.invoice_date,
                        'payment_journal_id':self.journal_id.id,
			'note':self.note,
                        }
                    custody_id = self.env['account.custody'].create(vals)
                    rec.custody_id = custody_id.id # assgin creating custody id to custody_id filed
        else:
            pass
         
                

  

    # inherit of the function from account.move to account_custody 
    # inherit button_draft to delete draft custody if you send the bill to draft 
    # return error masseage if the caustody state is paid
    def button_draft(self): 
        res = super(AccountMove, self).button_draft()
        for rec in self:
            custody_obj = self.env['account.custody'].search([])
            for custody in custody_obj:
                if custody.id == rec.custody_id.id: # check custody id 
                    if custody.state == 'draft': # check custody draft 
                        custody.unlink() # delete draft custody record by id 
                        rec.custody_id = [] # set null value to custody_id field
                    elif custody.state == 'paid':
                         raise ValidationError("Sorry This Bill Related With Custody You Have To Remove Payment first")
    
    def button_cancel(self):
        res = super(AccountMove, self).button_draft()
        for rec in self:
            custody_obj = self.env['account.custody'].search([])
            for custody in custody_obj:
                if custody.id == rec.custody_id.id: # check custody id 
                    if custody.state == 'draft': # check custody draft 
                        custody.unlink() # delete draft custody record by id 
                        rec.custody_id = [] # set null value to custody_id field
                    elif custody.state == 'paid':
                         raise ValidationError("Sorry This Bill Related With Custody You Have To Remove Payment first")

class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'
        
    def action_create_payments(self):
        res = super(AccountPaymentRegister, self).action_create_payments()
        for rec in self:
            custody_obj = self.env['account.custody'].search([])
            for custody in custody_obj:
                if custody.bill_id.name == rec.communication :
                    custody.state='paid'
                
                
            
        
        
        

    
      
        
            
