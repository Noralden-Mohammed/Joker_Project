from odoo import api, fields, models, _


class AccountJournal(models.Model):
    _inherit = 'account.journal'


    expense_type = fields.Selection([
            ('expense', 'General Expenses'),
            ('custody', 'Financial Custody'),
            ('salary', 'Salary'),],string="Expense Type ",

         help="this field used to determine method of journal \n"
              "Select the Type of Expense  corresponding to the you need .",)
    
class AccountAccountLine(models.Model):
    _name= 'account.account.line'
      
    
    account_custody_id=fields.Many2one('account.custody')
    account_move_id=fields.Many2one('account.move')
    name = fields.Many2one('account.account', string="Account Name", required=True,  tracking=True)
    debit_custody  = fields.Integer(string=" Debit")
    credit_custody  = fields.Integer(string=" Credit" , readonly=True)
    note = fields.Char()
    # total = fields.Float(compute='_compute_total')
    # default_account_id
    
 
    
    
  

    
    
    



    
