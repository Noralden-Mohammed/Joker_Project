# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = ['account.custody']
    _inherit = 'res.partner'
    custody_count = fields.Integer(string="Custody Count", compute='_compute_custody_count', tracking=True)

    # This Function Calculates The Number of Custody
    def _compute_custody_count(self):
        for rec in self:
            custody_count = self.env['account.custody'].search_count([('partner_id', '=', rec.name)])

            rec.custody_count = custody_count

    # This Function of Smart Button Custody Count
    def action_custody(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'custody',
            'res_model': 'account.custody',
            'domain': [('partner_id', '=', self.id)],
            'view_mode': 'tree,form',
            'target': 'current',

        }
