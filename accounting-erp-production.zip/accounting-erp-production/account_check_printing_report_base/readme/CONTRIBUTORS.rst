* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Lois Rilo Antelo <lois.rilo@eficent.com>
* Sandip Mangukiya <smangukiya@ursainfosystems.com>
* Manuel Marquez <mmarquez@iterativo.do>
* `Tecnativa <https://www.tecnativa.com>`_:

    * Luis M. Ontalba
    * Carlos Roca
