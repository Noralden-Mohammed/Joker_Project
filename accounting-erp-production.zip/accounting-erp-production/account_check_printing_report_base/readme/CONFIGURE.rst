Go to 'Settings / Users / Companies' and assign the desired check format.
This module proposes a basic layout, but other modules such as
"account_check_printing_report_dlt103" provide formats adjusted to known
check formats such as DLT103.
