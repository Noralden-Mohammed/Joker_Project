# -*- coding: utf-8 -*-
# from odoo import http


# class AccountBank(http.Controller):
#     @http.route('/account_bank/account_bank', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/account_bank/account_bank/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('account_bank.listing', {
#             'root': '/account_bank/account_bank',
#             'objects': http.request.env['account_bank.account_bank'].search([]),
#         })

#     @http.route('/account_bank/account_bank/objects/<model("account_bank.account_bank"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('account_bank.object', {
#             'object': obj
#         })
