from odoo import api, fields, models


class AccountPayment(models.TransientModel):
    # _name = 'account.inherit'
    _inherit = 'account.payment.register'
    _description = "Payment wizard"

    note = fields.Char(string="Note")

   
