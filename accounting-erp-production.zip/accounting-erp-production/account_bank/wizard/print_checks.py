from odoo import models, fields, api
from datetime import date
import datetime


class PrintChecks(models.TransientModel):
    _inherit = 'print.prenumbered.checks'
    
    print_type = fields.Selection(selection=[('print_new', 'Print New'),('reprint','Reprint'),('print','Print')])
    reason = fields.Char(string='Reason', tracking=True)
    old = fields.Char(tracking=True)
    check_number = fields.Char(string='Check Number', readonly=True)
    payment_method_code = fields.Char( readonly=True)
    is_move_sent = fields.Boolean()

    @api.model
    def default_get(self, fields):
        res = super().default_get(fields)
        active_id = self._context.get('active_id')
        brw_id = self.env['account.payment'].browse(int(active_id))
        if brw_id.print_type == 'reprint':
            res['print_type']='reprint'
            res['next_check_number'] = brw_id.check_number
        elif brw_id.print_type == 'print_new' :
            res['old'] = brw_id.check_number
            res['print_type']='print_new'
        elif brw_id.print_type == 'print' :
            res['print_type']='print'
        return res


    # This function inherit print check function and notcreate archive in journal
    def print_checks(self):
        result = super(PrintChecks, self).print_checks()
        active_id = self._context.get('active_id')
        payment_line_ids = self.env['account.payment'].browse(active_id)
        brw_id = self.env['account.payment'].browse(int(active_id))
        for rec in payment_line_ids:
            if brw_id.print_type == 'reprint':
                vals = {
                    'amount_check': rec.amount,
                    'check_numb': rec.check_number,
                    'journal_id': rec.journal_id.id,
                    'date_void': datetime.date.today(),
                    'date_check': datetime.date.today(),
                    'check_recipient': rec.check_recipient,
                    # 'reason': self.env['account.payment'].browse(int(active_id)).reason,
                    'move': rec.payment_move_id.name,
                    'check_state': 'reprint',
                    'reason': self.reason,
                }
                print('**************************',self.reason)
                
                res = self.env['account.payment.method.history'].create(vals)
                pwd = self.env['account.payment'].browse(int(active_id))
                # for rec in pwd:
                #     account_payment = self.env['account.payment.method.history'].search(
                #         [('check_numb', '=', rec.check_number), ('check_state', '=', 'reprint')])
                #     account_payment.reason = self.reason
                    # account_payment.date_void = rec.date
            elif brw_id.print_type == 'print_new':
                vals = {
                    'amount_check': rec.amount,
                    'check_numb': rec.check_number,
                    # 'old' : self.env['print.prenumbered.checks'].browse(int(active_id)).old,
                    'old' : self.old,
                    'journal_id': rec.journal_id.id,
                    'date_void': datetime.date.today(),
                    'date_check': datetime.date.today(),
                    'check_recipient': rec.check_recipient,
                    'move': rec.payment_move_id.name,
                    'reason': self.reason,
                    'check_state': 'print_new'
                    
                }
                
                res = self.env['account.payment.method.history'].create(vals)
                # bwd=self.env['print.prenumbered.checks'].browse(int(active_id))
                # for rec in bwd:
                #     account_payment = self.env['account.payment.method.history'].search(
                #         [('check_numb', '=', rec.check_number), ('check_state', '=', 'print')])
                #     account_payment.old = self.old

            elif brw_id.print_type == 'print' :
                vals = {
                    'amount_check': rec.amount,
                    'check_numb': rec.check_number,
                    'journal_id': rec.journal_id.id,
                    'date_check': datetime.date.today(),
                    'check_recipient': rec.check_recipient,
                    'move': rec.payment_move_id.name,
                    'check_state': 'print'
                }
                
                res = self.env['account.payment.method.history'].create(vals)

            return result

class RePrint(models.TransientModel):
    _name ='reprint.checks'
    # _inherit = 'print.prenumbered.checks'


    check_number = fields.Integer(string='Check Number', readonly=True)
    reason = fields.Char(string='Reason To Reprint Check', tracking=True, required=True)
    date = fields.Date(string='Reprint Date', defualt=fields.Datetime.now, tracking=True)

    @api.model
    def default_get(self, fields):
        res = super().default_get(fields)
        res['date'] = datetime.datetime.today()
        active_id = self._context.get('active_id')
        brw_id = self.env['account.payment'].browse(int(active_id))
        if active_id:
            res['check_number'] = brw_id.check_number
        return res

 
    def print_checks_jo(self):
        active_id = self._context.get('active_id')
        res = self.env['account.payment'].browse(active_id)
        # active_id = self._context.get('active_id')
        # res = super(RePrint,self).print_checks()
        payments = self.env['account.payment'].browse(self.env.context['active_id'])
        payment_line_ids = self.env['account.payment'].browse(active_id)
        for rec in payment_line_ids:
            vals = {
                'amount_check': rec.amount,
                'check_numb': rec.check_number,
                'journal_id': rec.journal_id.id,
                'date_check': datetime.date.today(),
                'check_recipient': rec.check_recipient,
                'move': rec.payment_move_id.name,
                'check_state': 'reprint',
               
            }
            res = self.env['account.payment.method.history'].create(vals)
        result = self.env['account.payment'].browse(active_id).print_checks()
        
        # result.state = 'posted'
        for rec in self:
            account_payment = self.env['account.payment.method.history'].search(
                [('check_numb', '=', rec.check_number), ('check_state', '=', 'reprint')])
            account_payment.reason = rec.reason
            account_payment.date_void = rec.date
        


        # print(">>>>>>>>>>>>>>>>>>>>>>>>>>>",self.check_number)
            # res = self.env['account.payment.method.history'].create(vals)
            # # lol = self.env['account.move'].search([('name', '=', rec.ref)])
            # return result
        
    

