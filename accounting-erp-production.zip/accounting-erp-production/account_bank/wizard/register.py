from odoo import api, fields, models , _
from odoo.exceptions import ValidationError



class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'
    
    _description = "register wizard"


    move_id = fields.Many2one('account.move', string="Move ID", tracking=True, readonly=True)
    note = fields.Char(string="Note", readonly=True,tracking=True)
    check_recipient = fields.Many2one('res.partner',string="Check Recipient",tracking=True)
    #This Function set default values of specific field to wizard 
    @api.model
    def default_get(self, fields):
        res = super(AccountPaymentRegister, self).default_get(fields)
        res['move_id'] = self.env.context.get('active_id')
        active_id = self._context.get('active_id')
        brw_id = self.env['account.move'].browse(int(active_id))
        
        if active_id :
            res['note']= brw_id.note
            res['check_recipient'] = brw_id.partner_id.id
        return res

    #This Function create and write values of specific field to another model 
    def action_create_payments(self):
        res = super(AccountPaymentRegister, self).action_create_payments()
        for rec in self:
            account_payment = self.env['account.payment'].search([])
            print("12346789")
            for payment in account_payment:
                if payment.ref==rec.communication :
                    payment.payment_move_id=rec.move_id.id
                    payment.note_id=rec.note
                    payment.check_recipient=rec.check_recipient.name
        return res  
