from odoo import models, fields, api
from datetime import date
import datetime


class VoidCheck(models.TransientModel):
    _name = 'account.paymnet.wizard.history.check'
    # _inherit = 'print.check'


    reason = fields.Char(string='Reason To Void Check', tracking=True,required=True)
    date_void = fields.Date(string='Void Date', defualt=fields.Datetime.now, tracking=True)
    check_numb = fields.Char(string='check_numb', readonly=True, tracking=True)
    # payment_id = fields.Many2one(string='Payment ID', comodel_name='account.payment')

    # This Function set default values of specific field to wizard
    @api.model
    def default_get(self, fields):
        res = super(VoidCheck, self).default_get(fields)
        res['date_void'] = datetime.datetime.today()
        active_id = self._context.get('active_id')
        brw_id = self.env['account.payment'].browse(int(active_id))
        if active_id:
            res['check_numb'] = brw_id.check_number
        return res


     # This function void the check and create archive in journal for check voided
    def action_void(self):
        active_id = self._context.get('active_id')
        res = self.env['account.payment'].browse(active_id).action_void_check()
        for rec in self:
            account_payment = self.env['account.payment.method.history'].search(
                [('check_numb', '=', rec.check_numb), ('check_state', '=', 'void')])
            account_payment.reason = rec.reason
        res_draft = self.env['account.payment'].browse(active_id).action_draft()
        set =self.env['account.payment'].browse(active_id)
        set.state = 'void'
        

class VoidCash(models.TransientModel):
    _name = 'account.paymnet.wizard.history.cash'
    
    reason = fields.Char(string='Reason To Void', tracking=True,required=True)
    date_void = fields.Date(string='Void Date', defualt=fields.Datetime.now, tracking=True)
    
    @api.model
    def default_get(self, fields):
        res = super(VoidCash, self).default_get(fields)
        res['date_void'] = datetime.datetime.today()
        return res
    
    
    def action_void_cash(self):
        active_id = self._context.get('active_id')
        pay_line_ids = self.env['account.payment'].browse(active_id)
        for rec in pay_line_ids:
            vals = {
                'reason': self.reason,
                'amount_check': rec.amount,
                'journal_id': rec.journal_id.id,
                'date_check': datetime.date.today(),
                'check_recipient': rec.check_recipient,
                'move': rec.payment_move_id.name,
                'check_state': 'void',
            }
            res = self.env['account.payment.method.history'].create(vals)
            rec.action_draft()
            rec.action_cancel()
            rec.state = 'void'
        return
      
        