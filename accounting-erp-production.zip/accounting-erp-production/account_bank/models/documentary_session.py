# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AccountMove(models.Model):
    _inherit = 'account.move'

    # replace state field with new state field
    state = fields.Selection(

        [('draft', 'Draft'), ('state_view', 'Reveiwed'), ('posted', 'Posted'), ('done', 'Done'),
         ('void', 'Voided'), ('cancel', 'Canceled'), ], default='draft')

    # this function to transform the state from draft to waiting for approve
    def action_wait(self):
        self.action_post()
        self.state = 'state_view'
        return

    # this function to transform the state from approve to review
    def action_approved(self):
        # vals = []
        res = super().action_post()
        # self.state = 'state_review'
        custody_count = self.env['account.custody'].search_count([('bill_id', '=', self.name)])
        if custody_count == 0:
            for rec in self:
                if rec.amount_total <= 0:
                    raise ValidationError("The Amount Total cannot be Zero in the bill")
                elif rec.journal_id.expense_type == 'custody':
                    vals = []
                    custody_id = self.env['account.custody'].create({

                        'state': 'draft',
                        'partner_id': self.partner_id.id,
                        'bill_id': self.id,
                        'amount': self.amount_total,
                        'payment_date': self.invoice_date,
                        'payment_journal_id': self.journal_id.id,
                        'note': self.note,
                    })
                    for line in self.invoice_line_ids:
                        vals = {
                            'account_custody_id': custody_id.id,
                            'name': line.account_id.id,
                            'credit_custody': line.price_subtotal,
                            'note': line.name,
                        }

                        self.env['account.account.line'].create(vals)
                    rec.custody_id = custody_id.id  # assign creating custody id to custody_id filed
                    # return   custody_id  
        else:
            pass
        return res

    # this function to transform the state from view to posted
    def action_post_inherit(self):
        self.action_post()
        return

    # this function to transform the state from review to viewed 
    def action_view(self):
        self.state = 'posted'
        return

    def action_back(self):
        self.state = 'draft'
        return

    # this function to transform the state from view to canceled
    def action_cancel(self):
        self.state = 'cancel'
        # active_id = self._context.get('active_id')
        # self.env['account.payment'].browse(active_id).unlink()

        return

    # def button_cancel(self):
    #     res =super(AccountMove, self).button_cancel()
    #     for rec in self:
    #         account_payment = self.env['account.payment'].search([])
    #         for payment in account_payment:
    #             print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",payment.ref)
    #             print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&",payment.payment_move_id.name)
    #             if payment.payment_move_id.name== rec.ref: # check custody id 
    #                 print("******************************************************")
    #                 payment.unlink() # delete draft custody record by id 
    #                 # rec.custody_id = [] # set null value to custody_id field
    #             else:
    #                 raise ValidationError("Sorry This Bill Related With Custody You Have To Remove Payment first")
    #     return res

    # this function to transform the state from view to posted


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    @api.model
    def default_get(self, fields):
        defaults = super().default_get(fields)
        defaults['name'] = '/'

        return defaults
