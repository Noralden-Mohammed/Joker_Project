from odoo import models, fields, api
from datetime import date
import datetime


class AccountPaymentRegister(models.Model):
    _inherit = ['account.move']

    payment_move_id = fields.Many2one(comodel_name='account.move', string='Move ID', readonly=True, tracking=True)
    note_id = fields.Char(string="Note", readonly=True, tracking=True)
    check_recipient = fields.Char(string="Check Recipient", readonly=True, tracking=True)
    check_number = fields.Char(string='Check Number', readonly=True)
    reason = fields.Char(string='Reason To Void Check', tracking=True)
    date_void = fields.Date(string='Void Date', defualt=fields.Datetime.now, tracking=True)


class AccountCheckJournal(models.Model):
    _inherit = ['account.journal']

    payment_line_ids = fields.One2many('account.payment.method.history', 'journal_id', string='Line', tracking=True)
    method = fields.Char(string='')



    #Function that return tree view of the Check History
    def action_check_history(self):
        domain = [('journal_id', '=', self.id)]
        return {
            'type': 'ir.actions.act_window',
            'name': 'check history',
            'res_model': 'account.payment.method.history',
            'views': [(self.env.ref('account_bank.view_account_payment_method_history_tree').id, 'tree')],
            'domain': domain,
            'view_mode': 'tree',
            'target': 'current',

        }
        
    def action_cash_history(self):
        domain = [('journal_id', '=', self.id)]
        return {
            'type': 'ir.actions.act_window',
            'name': 'cash history',
            'res_model': 'account.payment.method.history',
            'views': [(self.env.ref('account_bank.view_account_payment_method_history_cash_tree').id, 'tree')],
            'domain': domain,
            'view_mode': 'tree',
            'target': 'current',

        }

class CheckLine(models.Model):
    _name = 'account.payment.method.history'

    journal_id = fields.Many2one(comodel_name='account.journal', tracking=True)
    amount_check = fields.Char(string='Amount', readonly=True, tracking=True)
    date_check = fields.Char(string='Date', readonly=True, tracking=True)
    move = fields.Char(string='Move ID', readonly=True, tracking=True)
    check_numb = fields.Char(string='Check Number', readonly=True, tracking=True)
    check_recipient = fields.Char(tracking=True)
    reason = fields.Char( tracking=True)
    date_void = fields.Date(defualt=fields.Datetime.now, tracking=True)
    check_state = fields.Selection(string='State', selection=[('print', 'Print'), ('reprint','Reprinted'),('void', 'Void'),('print_new','New Print')], tracking=True)
    old = fields.Integer(string='Old Check',tracking=True)





class AccountPaymentVoid(models.Model):
    _inherit = 'account.payment'

    print_type = fields.Selection(selection=[('print_new', 'Print New'),('reprint','Reprint'),('print','Print')])
   # check_recipient = fields.Char(string="Check Recipient", readonly=True, tracking=True)

    def action_wizard_void_check(self):
        action = self.env.ref('account_bank.account_payment_print_check_void_action').read()[0]
        # for rec in self:
        #     rec.state = 'draft'
        return action

    def action_void_check(self):
        active_id = self._context.get('active_id')
        pay_line_ids = self.env['account.payment'].browse(active_id)
        for rec in pay_line_ids:
            vals = {
                'amount_check': rec.amount,
                'check_numb': rec.check_number,
                'journal_id': rec.journal_id.id,
                'date_check': datetime.date.today(),
                'date_void': datetime.date.today(),
                'check_recipient': rec.check_recipient,
                'move': rec.payment_move_id.name,
                'check_state': 'void',
            }
            res = self.env['account.payment.method.history'].create(vals)
            rec.state = 'cancel'
            rec.is_move_sent = False
            lol = self.env['account.move'].search([('name', '=', rec.ref)])
            
            return res

            
        super().action_void_check()

    # def print_checks():
    #     res = super().print_checks()
    
    def reprint_checks(self):
        self.print_type = 'reprint'
        # self.env['print.prenumbered.checks'].print_type = 'reprint'
        res = self.print_checks()
        # self.state = 'posted'
        # action = self.env.ref('account_bank.account_payment_reprint_check_action').read()[0]
        return res
    
    def print_new_checks(self):
        self.print_type = 'print_new'
        # self.env['print.prenumbered.checks'].print_type = 'print_new'
        res = self.print_checks()

        # self.state = 'posted'
        return res

    def print_checks_re(self):
        self.print_type= 'print'
        # self.env['print.prenumbered.checks'].print_type = 'print'
        res = super().print_checks()
        return res
        # pass
        # # result = self.print_checks()
        # active_id = self._context.get('active_id')
        # # res = super(RePrint,self).print_checks()
        # payments = self.env['account.payment'].browse(self.env.context['active_id'])
        # payment_line_ids = self.env['account.payment'].browse(active_id)
        # for rec in payment_line_ids:
        #     vals = {
        #         'amount_check': rec.amount,
        #         'check_numb': rec.check_number,
        #         'journal_id': rec.journal_id.id,
        #         'date_check': datetime.date.today(),
        #         'check_recipient': rec.check_recipient,
        #         'move': rec.payment_move_id.name,
        #         'check_state': 'reprint',
               
        #     }
        #     res = self.env['account.payment.method.history'].create(vals)
        #     print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1")
        # return res,result
    def action_print_report40(self):
        for rec in self:
            action = self.env.ref('account_payment_inh.report_payment_or_inh').read()[0]
            self.state = 'state_view'
            if rec.journal_id.type == 'cash':
                for res in rec:
                    vals = {
                        'amount_check': rec.amount,
                        'check_numb': rec.check_number,
                        'journal_id': rec.journal_id.id,
                        'date_check': datetime.date.today(),
                        'check_recipient': rec.check_recipient,
                        'move': rec.payment_move_id.name,
                        'check_state': 'print'
                    }
                
                    res=self.env['account.payment.method.history'].create(vals)
            return action
    
    def action_print_report17(self):
        action = self.env.ref('account_payment_inh.report_payment_receipt_inhi').read()[0]
        self.state = 'state_view'
        return action
    
    def action_payment_back(self):
        action = self.env.ref('account_bank.account_payment_print_cash_void_action').read()[0]
        # self.action_draft()
        # self.action_cancel()
        # self.state = 'void'
        return action
    
    def action_payment_review(self):
        self.state = 'done'
        return 
        
    
    cash_hide = fields.Boolean(compute="_compute_hide_report")
    bank_hide = fields.Boolean(_compute="_compute_hide_report")
    
    # @api.depends('cash_hide','bank_hide')
    def _compute_hide_report(self):
        for record in self:
            if record.journal_id.type == 'bank':
                self.cash_hide = True
                self.bank_hide = False
            elif record.journal_id.type == 'cash':
                self.bank_hide = True
                self.cash_hide =False
        return record