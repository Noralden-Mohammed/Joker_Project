# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = ['account.move']

    # payment_count = fields.Integer(string="Payment Count", compute='_compute_payment_count', tracking=True)
    note = fields.Char(string="Note")
    coment = fields.Text(string="Comment")
    approve_amount = fields.Float(string='Approve Amount')
    document = fields.Binary(string='Document')

    # invoice_readonly = fields.Boolean(compute='_compute_invoice_line_ids_readonly')
    invoice_line_ids = fields.One2many(  # /!\ invoice_line_ids is just a subset of line_ids.
        'account.move.line',
        'move_id',
        string='Invoice lines',
        copy=False,
        readonly=False,
        domain=[('display_type', 'in', ('product', 'line_section', 'line_note'))],
        states={'draft': [('readonly', True)]},
    )

    # @api.depends('state')
    # def _compute_invoice_line_ids_readonly(self):
    #     for rec in self:
    #         if rec.state == 'draft':
    #             if rec.move_type == 'in_invoice':
    #                 rec.invoice_readonly = True
    #             elif rec.move_type == 'out_invoice':
    #                 rec.invoice_readonly = False
    #         elif rec.state == 'status_approved':
    #             rec.invoice_readonly = False
    #         else:
    #             rec.invoice_readonly = True

    # This Function Calculates The Number of Payments
    # def _compute_payment_count(self):
    #     for rec in self:
    #         payment_count = self.env['account.payment'].search_count([('payment_move_id', '=', rec.id)])
    #         # payment_count = self.env['account.payment'].search_count([('partner_id', '=', rec.partner_id.id)])
    #         rec.payment_count = payment_count

    # # This Function of Smart Button Payment Count
    # def action_payment(self):
    #     for rec in self:
    #         domain = [('payment_move_id','=',rec.id)]
    #         return {
    #             'type': 'ir.actions.act_window',
    #             'name': 'payment',
    #             'res_model': 'account.payment',
    #             'domain': domain,
    #             'view_mode': 'tree,form',
    #             'target': 'current',

    #         }
