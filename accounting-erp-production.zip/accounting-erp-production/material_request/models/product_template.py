# -*- coding: utf-8 -*-
from odoo import models, fields, api , _

class ProductTemplate(models.Model):
    _inherit = ['product.template']
    
    # inherit and add field in product.template model 
    car_ok = fields.Boolean(string="Car", tracking=True)
    custody_ok = fields.Boolean(string="Custody", tracking=True)