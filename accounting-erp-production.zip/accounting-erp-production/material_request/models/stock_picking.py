# -*- coding: utf-8 -*-
from datetime import date
from odoo import models, fields, api , _
from datetime import datetime
from datetime import date


class Stock_Picking(models.Model):
    _inherit = ['stock.picking']
 
    department_id = fields.Many2one('hr.department' , string='Department Name',  readonly=True, tracking=True)
    emp_id = fields.Many2one('hr.employee' , string='Employee Name', readonly=True,  tracking=True)

    type_order = fields.Selection([
      ('1','Employee'),
      ('2','Department'),
      ('3','Out of Rapid Support Forces')], string="Type of Order", readonly=True, tracking=True)
     
    grantee_name = fields.Many2one('res.partner',string="Grantee Name" , readonly=True)
    externat_dpartment_id = fields.Many2one('externat.dpartment', readonly=True,  string="External Dpartment")
     
    receipt_id = fields.Many2one('hr.employee' , string='Recepit Name', tracking=True)

    date_receipt = fields.Date(string="Receipt Date", default=datetime.today(),  tracking=True)
    
    vendor_id = fields.Many2one('res.partner' , string='Vendor', tracking=True)

    def action_print_12_c(self):
        return self.env.ref('material_request.print_12c_in_stock').report_action(self)

    def button_validate(self):
        super().button_validate()
        vals={}
        if self.picking_type_code=='outgoing':
            for line in self.move_line_ids_without_package:
              
              line.lot_id.department_id=self.department_id.id
              line.lot_id.emp_id=self.emp_id.id
              line.lot_id.grantee_name=self.grantee_name.id
              line.lot_id.externat_dpartment_id=self.externat_dpartment_id.id #change field name to external_department_id
              line.lot_id.receipt_id=self.receipt_id.id
              line.lot_id.date_receipt=self.date_receipt
              line.lot_id.type_order = self.type_order
              vals={
                  'picking_id':self.id,
                  'emp_id':self.emp_id.id,
                  'department_id':self.department_id.id,
                  'grantee_name':self.grantee_name.id,
                  'receipt_id':self.receipt_id.id,
                  'date_receipt':self.date_receipt,
                  'externat_dpartment_id':self.externat_dpartment_id.id,
                  'lot_id':line.lot_id.id,
                }
              self.env['stock.lot.line'].create(vals)
        
        if self.picking_type_code=='incoming':  
           for product_line in self.move_line_ids_without_package:
             if product_line.product_id.car_ok==True:
              for line in self.move_line_nosuggest_ids:                  
                  lot_id = self.env['stock.lot'].search([('name','=',line.lot_name)])
                  lot_id.car_ok=True
                  lot_id.plate_no=line.plate_no
                  lot_id.mechine_no=line.mechine_no
                  lot_id.fuel_type=line.fuel_type