from odoo import models, fields, api , _

class ExternatDepartment(models.Model):
    _name = 'externat.dpartment'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Externat Department'

     
    name = fields.Char(string="External Department", required=True , tracking=True)