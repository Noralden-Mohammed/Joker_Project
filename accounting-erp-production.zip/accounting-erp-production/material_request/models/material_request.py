# -*- coding: utf-8 -*-
from datetime import date
from odoo import models, fields, api , _
import qrcode
import base64
import io
from datetime import datetime
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from logging import warning
from odoo.exceptions import ValidationError,Warning

class MaterialRequest(models.Model):
   _name = 'material.request'
   _inherit = ['mail.thread','mail.activity.mixin']
   _description = 'material_request'
   _rec_name = 'seq_material'
   
   #fields for  materialrequest model 
   seq_material = fields.Char(string='Reference', required=True, copy=False, readonly=True, default=lambda self:_('New'))
   note_number_f = fields.Char(string='Note Number')

   type_order = fields.Selection([
      ('1','Employee'),
      ('2','Department'),
      ('3','Out of Rapid Support Forces')], string="Type of Order",  required=True , tracking=True)
   grantee_name = fields.Many2one('res.partner',string="Grantee Name" ,  )
   externat_dpartment_id = fields.Many2one('externat.dpartment', string="External Department")

   emp_id = fields.Many2one('hr.employee', string="Employee Name", tracking=True)
   department_id = fields.Many2one("hr.department", string="Department Name", tracking=True) # , related='emp_id.department_id'
   product_ids = fields.One2many('product.lines', 'material_request_id', string="ids", tracking=True)
   request_date = fields.Date(string="Request Date" , default=datetime.today() ,tracking=True)
   status = fields.Selection([
      ('draft', 'Draft'),
      ('approve', 'Approve'),
      ('send_to_inventory', 'In Stock'),
      ('paid_off', 'Delivery'),
      ('done', 'Done'),
      ('cancel', 'Cancel')], default="draft", string="Status", required=True , tracking=True)
   qr_code = fields.Binary('QRcode',compute="_generate_qr" )
  
   material_request_count = fields.Integer(string="Material Request Count", compute='_compute_material_request_count',tracking=True)

   # Smart Buttom
   def _compute_material_request_count(self):
      for rec in self:
         material_request_count = self.env['stock.picking'].search_count([('origin','=', self.seq_material)])
         rec.material_request_count = material_request_count

   def action_material_request(self):
      return {
         'type': 'ir.actions.act_window',
         'name': 'Material Request',
         'res_model': 'stock.picking',
         'domain': [('origin','=', self.seq_material)],
         'view_mode': 'tree,form' ,
         'target': 'current',
      }
      
   # Genaret QR
   def _generate_qr(self):
        "method to generate QR code"
        for rec in self:
           if qrcode and base64:
               qr = qrcode.QRCode(
                   version=1,
                   error_correction=qrcode.constants.ERROR_CORRECT_L,
                   box_size=3,
                   border=4,
               )
               qr.add_data("ID :")
               qr.add_data(rec.seq_material)
               qr.add_data("\nEmployee Name :")
               qr.add_data(rec.emp_id.name)
               qr.add_data("\nDepartment :")
               qr.add_data(rec.department_id.name)
               qr.add_data("\nDate :")
               qr.add_data(rec.request_date)
               qr.make(fit=True)
               img = qr.make_image()
               temp = io.BytesIO()
               img.save(temp, format="PNG")
               qr_image = base64.b64encode(temp.getvalue())
               rec.update({'qr_code':qr_image})
               
   #create method use to make sequence 
   @api.model
   def create(self, vals):
      if vals.get('seq_material', _('New')) == _('New'):
         vals['seq_material'] = self.env['ir.sequence'].next_by_code('material.request') or _('New')
      result = super(MaterialRequest, self).create(vals)
      return result   

   def action_draft(self):
        self.status = 'draft'
        
   def action_approve(self):
         for rec in self.product_ids:
            rec.approval_quantity = rec.request_quantity

         for pro in self:
            for check_pro in pro.product_ids: 
               if check_pro.material_request_id:
                  self.status = 'approve'
                  return True
            raise ValidationError(_("Please Choose Any product !"))
        
   def action_cancel(self):
        self.status = 'cancel'

   def print_paid(self):
      return self.env.ref('material_request.report_dismissal_notice_pdf').report_action(self)
       
   def action_send_to_inventory(self):   
      pick_type_id = self.env['stock.picking.type'].search([('code','=','outgoing')])[0].id
      location_model = self.env['stock.location']
      location_dest_id = location_model.search([('usage', '=', 'customer')])[0].id
      move_model = self.env['stock.move']
      for rec in self.product_ids:
         picking = self.env['stock.picking'].search([('location_id','=',rec.location_id.id),
            ('origin','=',self.seq_material),('state','not in',['cancel','done'])])
         for pick in picking:               
            vals={
                  'product_id' : rec.product_id.id,
                  'product_uom_id' : rec.uom_id.id,
                  'qty_done' : rec.approval_quantity,
                  'location_dest_id' : location_dest_id, 
                  'location_id' : rec.location_id.id,
                  'picking_id':pick.id
            }
            self.env['stock.move.line'].create(vals)
         if not picking:
            picking_obj = self.env['stock.picking'].create({
                  'picking_type_id' : pick_type_id,
                  'origin' : self.seq_material,
                  'location_id' : rec.location_id.id,     
                  'location_dest_id' : location_dest_id,  
                  'type_order' : self.type_order,
                  'emp_id': self.emp_id.id,
                  'department_id': self.department_id.id,
                  'grantee_name': self.grantee_name.id,
                  'externat_dpartment_id': self.externat_dpartment_id.id,
                  'scheduled_date': self.request_date,
                  'executing_agency_id':self.executing_agency_id.id,
            })
            vals={
                  'product_id' : rec.product_id.id,
                  'product_uom_id' : rec.uom_id.id,
                  'qty_done' : rec.approval_quantity,
                  'location_dest_id' : location_dest_id, 
                  'location_id' : rec.location_id.id,
                  'picking_id':picking_obj.id

            }
            self.env['stock.move.line'].create(vals)
            picking_obj.action_confirm()
            picking_obj.action_assign()
      self.status = 'send_to_inventory'
            
class ProductLines(models.Model):
   _name = 'product.lines'  
   _description = 'product_lines' 

   category_id = fields.Many2one('product.category', string="Product Category", required=True , tracking=True)
   product_id = fields.Many2one("product.template",string="Product", required=True , tracking=True)
   uom_id = fields.Many2one('uom.uom', string="Unit Of Measure", required=True , tracking=True )
   request_quantity = fields.Float(string="Request Quantity", required=True, tracking=True)
   on_hand = fields.Float(string="On Hand", tracking=True)
   approval_quantity = fields.Float( string="Approval Quantity", tracking=True)
   remaining_quantity = fields.Float( string="Remaining Quantity", tracking=True)
   location_id = fields.Many2one('stock.location', domain="[('usage','=','internal')]" , string="Location Name", tracking=True)
   material_request_id = fields.Many2one('material.request', string="material request id")
   picked = fields.Boolean(string='Picking')
   
   @api.onchange('product_id')
   def onchange_product(self):
        category_id = self.product_id.uom_id.category_id.id
        return {
            'domain' : {
               'uom_id' : [('category_id', '=', category_id)]
            },
            'value' : {
               'uom_id' : False,
            }
        }
        
   @api.onchange("location_id", "on_hand")
   def _check_quantity_on_hand(self):
      for rec in self:
         if rec.product_id.tracking=='serial':
            check_quantity = self.env['stock.quant'].search_count([('location_id','=',rec.location_id.id),('product_id','=',rec.product_id.id)])
            rec.on_hand = check_quantity   
            
         if rec.product_id.tracking=='none':
            check_quantity = self.env['stock.quant'].search([('location_id','=',rec.location_id.id),('product_id','=',rec.product_id.id)])
            rec.on_hand = check_quantity.quantity   
      
   @api.constrains("request_quantity")
   def _check_field(self):
     for r in self:
          if r.request_quantity == 0:
               raise ValidationError(_("The number zero cannot be entered"))     

class StockPicking(models.Model): 
      _inherit = 'stock.picking'
    
      def button_validate(self):
         super().button_validate()
         # res = super(StockPicking, self)
         res = self.env.get('material.request').search([('seq_material', '=', self.origin)]).write({'status' : 'paid_off'})
         return res
         
           
