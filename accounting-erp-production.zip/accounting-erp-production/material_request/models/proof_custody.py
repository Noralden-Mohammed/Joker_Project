# -*- coding: utf-8 -*-
from datetime import date
from odoo import models, fields, api , _


class ProofCustody(models.Model):
    _inherit = ['stock.lot']
 
    type_order = fields.Selection([
      ('1','Employee'),
      ('2','Department'),
      ('3','Out of Rapid Support Forces')], string="Type of Order", tracking=True)
     
    department_id = fields.Many2one('hr.department' , string='Department Name',  tracking=True)
    emp_id = fields.Many2one('hr.employee' , string='Employee Name',  tracking=True)
    grantee_name = fields.Many2one('res.partner',string="Grantee Name")
    externat_dpartment_id = fields.Many2one('externat.dpartment', string="Externat Dpartment")
    receipt_id = fields.Many2one('hr.employee', string="Receipt Name")
    date_receipt = fields.Date(string="Receipt Date" ,  tracking=True)
    # status_stock_lot = fields.Selection([(1,"Delivered"),(2,"In Stock"),(3,"Scrap")], string='State')
    car_ok = fields.Boolean(string="Is Car" )
    plate_no = fields.Char(string="Plate NO", readonly=True)
    mechine_no = fields.Char(string="Mechine NO", readonly=True)
    fuel_type = fields.Selection([
        ('diesel', 'Diesel'),
        ('gasoline', 'Gasoline'),
        
    ] , default='diesel',)
    line_ids = fields.One2many('stock.lot.line','lot_id', string='Lot ID')
    
     
class STockLotLine(models.Model):
        
    _name = 'stock.lot.line'
    
    picking_id = fields.Many2one('stock.picking', string="Reference")
    emp_id = fields.Many2one('hr.employee' , string='Employee Name',  tracking=True)
    department_id = fields.Many2one('hr.department' , string='Department Name',  tracking=True)
    grantee_name = fields.Many2one('res.partner',string="Grantee Name")
    receipt_id = fields.Many2one('hr.employee', string="Receipt Name")
    date_receipt = fields.Date(string="Receipt Date")
    date_remove = fields.Many2one('stock.picking', string="Remove Date")
    lot_id = fields.Many2one(comodel_name='stock.lot', string='ID')
    externat_dpartment_id = fields.Many2one('externat.dpartment', readonly=True,  string="Externat Dpartment")

    state = fields.Selection([
        ('assign', 'Assigned'),
        ('in_stock', 'In Stock'),
        
        ] , default='assign',)


class StockMove(models.Model):
    _inherit = 'stock.move'
    
    car_ok = fields.Boolean(string="Is Car" , related="product_id.car_ok")
    
class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'
    
    plate_no = fields.Char(string="Plate NO")
    mechine_no = fields.Char(string="Mechine NO",)
    fuel_type = fields.Selection([
        ('diesel', 'Diesel'),
        ('gasoline', 'Gasoline'),
        
    ] , default='diesel',)