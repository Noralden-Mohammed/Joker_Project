from odoo import api, models, fields


#=======================================
class AccountMovee(models.Model):
    _inherit = 'account.move'
    _description = "Account Movee"
    # picking_customer_note = fields.Text(string='Picking Customer Comments' 
    # ,required=True
    # )
    sales_person_contact = fields.Many2one('res.partner',  string="Salesperson Contact")
    sales_person_email = fields.Char(string="Salesperson Email")
    
class AccountPayment(models.Model):
    _inherit = 'account.payment'
    
    