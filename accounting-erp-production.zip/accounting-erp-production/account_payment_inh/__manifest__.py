# -*- coding: utf-8 -*-

{
    'name': 'Accounting Move Inherit',
    'version': '1.0.0.0',
    'category': 'Move',
    'description': ' ',
    'summary': 'Accounting Inherit For Odoo 16',
    'sequence': '2',
    'author': '',
    'license': 'LGPL-3',
    'company': 'RSF Dev',
    'maintainer': 'RSF DEV',
    'support': '',
    'website': '',
    'depends': ['account'],
    'live_test_url': '',
    'data': [
        # 'security/ir.model.access.csv',
        'report/report.xml',
        'report/report_payment_17.xml',
        'report/report_payment_40.xml',
    ],
    # 'pre_init_hook': '_pre_init_clean_m2m_models',
    'installable': True,
    'application': False,
    'auto_install': False,
    # 'images': ['static/description/banner.gif'],
}
